export class ChamaaiDto {
  enabled: boolean;
  url: string;
  token: string;
  waNumber: string;
  answerByAudio: boolean;
}
