export class ChatwootDto {
  enabled?: boolean;
  account_id?: string;
  token?: string;
  url?: string;
  name_inbox?: string;
  sign_msg?: boolean;
  number?: string;
  reopen_conversation?: boolean;
  conversation_pending?: boolean;
}
